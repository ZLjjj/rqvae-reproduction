from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset


class EmbDataset(Dataset):
    """Memory-mapped embedding dataset used by SID train/inference scripts."""

    def __init__(self, data_npy: str):
        self.path = Path(data_npy)
        self.data = np.load(self.path, mmap_mode="r")
        if self.data.ndim != 2:
            raise ValueError(f"Expected a 2D embedding matrix, got {self.data.shape}")
        self.dim = int(self.data.shape[1])

    def __len__(self):
        return int(self.data.shape[0])

    def __getitem__(self, idx):
        return torch.from_numpy(np.asarray(self.data[idx], dtype=np.float32))
